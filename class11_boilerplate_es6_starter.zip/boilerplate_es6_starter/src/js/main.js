
/* This is my first code
 * this is what it does
 */
console.log('ccxxxx');

//import all:
import stats from './stats.js';
var counts = [1,3,5,7];
console.log(counts);

console.log(stats.meanOfValues(counts));

console.log( 'e6 module', stats );
//import default